document.addEventListener('DOMContentLoaded', function() {
    // Initialize calculator functionality
    initCalculator();
    
    // Form validation
    setupFormValidation();
    
    // Mobile menu toggle
    setupMobileMenu();

    // Slider functionality
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelector('.slider-dots');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    let currentSlide = 0;
    let slideInterval;

    // Create dots
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.classList.add('dot');
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => goToSlide(index));
        dots.appendChild(dot);
    });

    const dotElements = document.querySelectorAll('.dot');

    function updateSlider() {
        slides.forEach((slide, index) => {
            slide.classList.remove('active');
            dotElements[index].classList.remove('active');
        });
        slides[currentSlide].classList.add('active');
        dotElements[currentSlide].classList.add('active');
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        updateSlider();
    }

    function prevSlide() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        updateSlider();
    }

    function goToSlide(index) {
        currentSlide = index;
        updateSlider();
        resetInterval();
    }

    function resetInterval() {
        clearInterval(slideInterval);
        slideInterval = setInterval(nextSlide, 5000);
    }

    // Event listeners
    prevBtn.addEventListener('click', () => {
        prevSlide();
        resetInterval();
    });

    nextBtn.addEventListener('click', () => {
        nextSlide();
        resetInterval();
    });

    // Start automatic slideshow
    resetInterval();

    // Mobile Menu Toggle
    const hamburger = document.querySelector('.hamburger-menu');
    const nav = document.querySelector('.main-nav');
    
    hamburger.addEventListener('click', function() {
        hamburger.classList.toggle('active');
        nav.classList.toggle('active');
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!hamburger.contains(event.target) && !nav.contains(event.target)) {
            hamburger.classList.remove('active');
            nav.classList.remove('active');
        }
    });
});

function initCalculator() {
    const calculateButton = document.getElementById('calculate-button');
    const totalFeesElement = document.getElementById('total-fees');

    calculateButton.addEventListener('click', function() {
        const selectedCourses = document.querySelectorAll('input[name="courses"]:checked');
        let totalFee = 0;

        selectedCourses.forEach(course => {
            totalFee += parseFloat(course.value);
        });

        let discountAmount = 0;
        let feeAfterDiscount = totalFee;

        // Apply discounts
        if (selectedCourses.length === 2) {
            discountAmount = totalFee * 0.05;
            feeAfterDiscount = totalFee * 0.95; // 5% discount
        } else if (selectedCourses.length === 3) {
            discountAmount = totalFee * 0.10;
            feeAfterDiscount = totalFee * 0.90; // 10% discount
        } else if (selectedCourses.length > 3) {
            discountAmount = totalFee * 0.15;
            feeAfterDiscount = totalFee * 0.85; // 15% discount
        }

        // Add VAT (15%)
        const finalTotalFee = feeAfterDiscount * 1.15;

        totalFeesElement.innerHTML = `Discount Received: R${discountAmount.toFixed(2)}<br>Total Fee (including VAT): R${finalTotalFee.toFixed(2)}`;
    });
}

function setupFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
    });
}

function validateForm(form) {
    let isValid = true;
    const requiredFields = form.querySelectorAll('[required]');
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            isValid = false;
            field.style.borderColor = 'var(--error)';
            
            // Add error message if not exists
            if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('error-message')) {
                const errorMsg = document.createElement('div');
                errorMsg.className = 'error-message';
                errorMsg.style.color = 'var(--error)';
                errorMsg.style.fontSize = '0.8rem';
                errorMsg.style.marginTop = '0.25rem';
                errorMsg.textContent = 'This field is required';
                field.parentNode.insertBefore(errorMsg, field.nextSibling);
            }
        } else {
            field.style.borderColor = '';
            
            // Remove error message if exists
            if (field.nextElementSibling && field.nextElementSibling.classList.contains('error-message')) {
                field.nextElementSibling.remove();
            }
        }
    });
    
    if (!isValid) {
        const firstError = form.querySelector('[required]:invalid');
        if (firstError) {
            firstError.focus();
        }
        alert('Please fill in all required fields correctly.');
    }
    
    return isValid;
}

function setupMobileMenu() {
    const menuToggle = document.getElementById('menuToggle');
    if (!menuToggle) return;
    
    const nav = document.querySelector('nav');
    
    menuToggle.addEventListener('click', function() {
        nav.classList.toggle('active');
    });
}