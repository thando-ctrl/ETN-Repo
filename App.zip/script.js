// Course data
const courses = {
    sixMonth: [
        {
            id: 1,
            title: "First Aid",
            duration: "6 months",
            fee: 1500,
            purpose: "To provide first aid awareness and basic life support",
            content: [
                "Wounds and bleeding",
                "Burns and fractures",
                "Emergency scene management",
                "Cardio-Pulmonary Resuscitation (CPR)",
                "Respiratory distress e.g., Choking, blocked airway"
            ]
        },
        {
            id: 2,
            title: "Sewing",
            duration: "6 months",
            fee: 1500,
            purpose: "To provide alterations and new garment tailoring services",
            content: [
                "Types of stitches",
                "Threading a sewing machine",
                "Sewing buttons, zips, hems and seams",
                "Alterations",
                "Designing and sewing new garments"
            ]
        },
        {
            id: 3,
            title: "Landscaping",
            duration: "6 months",
            fee: 1500,
            purpose: "To provide landscaping services for new and established gardens",
            content: [
                "Indigenous and exotic plants and trees",
                "Fixed structures (fountains, statues, benches, tables, built-in braai)",
                "Balancing of plants and trees in a garden",
                "Aesthetics of plant shapes and colours",
                "Garden layout"
            ]
        },
        {
            id: 4,
            title: "Life Skills",
            duration: "6 months",
            fee: 1500,
            purpose: "To provide skills to navigate basic life necessities",
            content: [
                "Opening a bank account",
                "Basic labour law (know your rights)",
                "Basic reading and writing literacy",
                "Basic numeric literacy"
            ]
        }
    ],
    sixWeek: [
        {
            id: 5,
            title: "Child Minding",
            duration: "6 weeks",
            fee: 750,
            purpose: "To provide basic child and baby care",
            content: [
                "Birth to six-month old baby needs",
                "Seven-month to one year old needs",
                "Toddler needs",
                "Educational toys"
            ]
        },
        {
            id: 6,
            title: "Cooking",
            duration: "6 weeks",
            fee: 750,
            purpose: "To prepare and cook nutritious family meals",
            content: [
                "Nutritional requirements for a healthy body",
                "Types of protein, carbohydrates and vegetables",
                "Planning meals",
                "Tasty and nutritious recipes",
                "Preparation and cooking of meals"
            ]
        },
        {
            id: 7,
            title: "Garden Maintenance",
            duration: "6 weeks",
            fee: 750,
            purpose: "To provide basic knowledge of watering, pruning and planting in a domestic garden",
            content: [
                "Water restrictions and the watering requirements of indigenous and exotic plants",
                "Pruning and propagation of plants",
                "Planting techniques for different plant types"
            ]
        }
    ]
};

// DOM Elements
const sixMonthCoursesContainer = document.getElementById('sixMonthCourses');
const sixWeekCoursesContainer = document.getElementById('sixWeekCourses');
const courseCheckboxes = document.getElementById('courseCheckboxes');
const calculateButton = document.getElementById('calculateButton');
const feeCalculator = document.getElementById('feeCalculator');
const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('.nav-menu');

// Function to create course cards
function createCourseCard(course) {
    const courseImage = course.id === 1 ? 
        'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3' : 
        course.id === 2 ?
        'https://images.unsplash.com/photo-1560807707-8cc77767d783?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3' :
        course.id === 3 ?
        'https://images.unsplash.com/photo-1558904541-efa843a96f01?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3' :
        course.id === 4 ?
        'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3' :
        '';

    return `
        <div class="course-card">
            ${courseImage ? `<div class="course-image">
                <img src="${courseImage}" alt="${course.title}">
            </div>` : ''}
            <div class="course-content">
                <h3 class="course-title">${course.title}</h3>
                <span class="course-category">${course.duration}</span>
                <p class="course-description">${course.purpose}</p>
                <div class="course-details">
                    <span>Fee: R${course.fee}</span>
                </div>
                <div class="course-content-list">
                    <h4>Course Content:</h4>
                    <ul>
                        ${course.content.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                </div>
            </div>
        </div>
    `;
}

// Function to create course checkboxes
function createCourseCheckboxes() {
    const allCourses = [...courses.sixMonth, ...courses.sixWeek];
    return allCourses.map(course => `
        <div class="course-checkbox">
            <input type="checkbox" id="course${course.id}" value="${course.fee}" data-title="${course.title}">
            <label for="course${course.id}">${course.title} - R${course.fee} (${course.duration})</label>
        </div>
    `).join('');
}

// Function to calculate total with discounts
function calculateTotal() {
    const selectedCourses = Array.from(document.querySelectorAll('.course-checkbox input:checked'));
    const subtotal = selectedCourses.reduce((sum, course) => sum + parseFloat(course.value), 0);
    
    let discount = 0;
    if (selectedCourses.length === 2) {
        discount = subtotal * 0.05; // 5% discount
    } else if (selectedCourses.length === 3) {
        discount = subtotal * 0.10; // 10% discount
    } else if (selectedCourses.length > 3) {
        discount = subtotal * 0.15; // 15% discount
    }

    const afterDiscount = subtotal - discount;
    const vat = afterDiscount * 0.15; // 15% VAT
    const total = afterDiscount + vat;

    document.getElementById('subtotal').textContent = subtotal.toFixed(2);
    document.getElementById('discount').textContent = discount.toFixed(2);
    document.getElementById('vat').textContent = vat.toFixed(2);
    document.getElementById('total').textContent = total.toFixed(2);
}

// Function to validate form
function validateForm() {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const selectedCourses = document.querySelectorAll('.course-checkbox input:checked');

    if (!name || !phone || !email) {
        alert('Please fill in all contact details');
        return false;
    }

    if (selectedCourses.length === 0) {
        alert('Please select at least one course');
        return false;
    }

    // Phone number validation (South African format)
    const phoneRegex = /^(\+27|0)[6-8][0-9]{8}$/;
    if (!phoneRegex.test(phone)) {
        alert('Please enter a valid South African phone number');
        return false;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return false;
    }

    return true;
}

// Initialize the app
function initApp() {
    // Display courses
    sixMonthCoursesContainer.innerHTML = courses.sixMonth.map(course => createCourseCard(course)).join('');
    sixWeekCoursesContainer.innerHTML = courses.sixWeek.map(course => createCourseCard(course)).join('');
    
    // Create course checkboxes
    courseCheckboxes.innerHTML = createCourseCheckboxes();

    // Event Listeners
    calculateButton.addEventListener('click', calculateTotal);
    
    feeCalculator.addEventListener('submit', (e) => {
        e.preventDefault();
        if (validateForm()) {
            // Here you would typically send the data to a server
            alert('Thank you for your interest! A consultant will contact you shortly.');
            feeCalculator.reset();
            calculateTotal();
        }
    });

    // Mobile menu toggle
    menuToggle.addEventListener('click', () => {
        menuToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!menuToggle.contains(e.target) && !navMenu.contains(e.target)) {
            menuToggle.classList.remove('active');
            navMenu.classList.remove('active');
        }
    });

    // Close menu when clicking a link
    document.querySelectorAll('.nav-menu a').forEach(link => {
        link.addEventListener('click', () => {
            menuToggle.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
                // Close mobile menu if open
                navMenu.classList.remove('active');
            }
        });
    });

    // Logout functionality
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            // Here you would typically clear any session data or tokens
            // For now, we'll just redirect to the login page
            window.location.href = 'login.html';
        });
    }
}

// Initialize the app when the DOM is loaded
document.addEventListener('DOMContentLoaded', initApp); 