# College Courses Mobile Web App

A responsive web application for displaying and searching college courses. Built with HTML, CSS, and JavaScript.

## Features

- Responsive design that works on all devices
- Course search functionality
- Category filtering
- Modern and clean user interface
- Mobile-first approach
- Dynamic course cards with images

## Project Structure

- `index.html` - Main HTML file
- `styles.css` - CSS styles
- `script.js` - JavaScript functionality
- `README.md` - Project documentation

## Getting Started

1. Clone the repository
2. Open `index.html` in your web browser
3. No build process required - it's a simple static website

## Customization

### Adding New Courses

To add new courses, modify the `courses` array in `script.js`. Each course should follow this structure:

```javascript
{
    id: number,
    title: string,
    category: string,
    description: string,
    duration: string,
    level: string,
    image: string
}
```

### Modifying Categories

To add or modify categories:
1. Update the category options in `index.html`
2. Add corresponding course entries in `script.js`

## Browser Support

The application works on all modern browsers that support:
- CSS Grid
- Flexbox
- ES6 JavaScript features

## Future Improvements

- Add user authentication
- Implement a backend API
- Add course enrollment functionality
- Include course ratings and reviews
- Add a shopping cart for course registration 